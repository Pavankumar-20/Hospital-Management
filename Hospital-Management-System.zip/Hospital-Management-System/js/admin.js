/**
 * Admin Dashboard Functionality
 */

document.addEventListener('DOMContentLoaded', () => {
  initAdminCharts();
  initAdminForms();
  initReportGeneration();
});

function initAdminCharts() {
  if (typeof Chart === 'undefined') return;

  // Patient Statistics Chart
  const patientCtx = document.getElementById('patientChart');
  if (patientCtx) {
    new Chart(patientCtx, {
      type: 'line',
      data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul'],
        datasets: [{
          label: 'New Patients',
          data: [65, 78, 90, 85, 99, 110, 125],
          borderColor: '#0ea5e9',
          backgroundColor: 'rgba(14, 165, 233, 0.1)',
          fill: true,
          tension: 0.4
        }, {
          label: 'Appointments',
          data: [120, 135, 150, 140, 165, 180, 195],
          borderColor: '#10b981',
          backgroundColor: 'rgba(16, 185, 129, 0.1)',
          fill: true,
          tension: 0.4
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { position: 'top' } },
        scales: { y: { beginAtZero: true } }
      }
    });
  }

  // Department Distribution Chart
  const deptCtx = document.getElementById('departmentChart');
  if (deptCtx) {
    new Chart(deptCtx, {
      type: 'doughnut',
      data: {
        labels: ['Cardiology', 'Neurology', 'Orthopedics', 'Pediatrics', 'Dermatology', 'General'],
        datasets: [{
          data: [25, 18, 22, 15, 10, 10],
          backgroundColor: ['#0ea5e9', '#10b981', '#f59e0b', '#8b5cf6', '#ec4899', '#6366f1']
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { position: 'right' } }
      }
    });
  }

  // Revenue Chart
  const revenueCtx = document.getElementById('revenueChart');
  if (revenueCtx) {
    new Chart(revenueCtx, {
      type: 'bar',
      data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [{
          label: 'Revenue ($)',
          data: [45000, 52000, 48000, 61000, 55000, 67000],
          backgroundColor: 'rgba(14, 165, 233, 0.8)',
          borderRadius: 8
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: { y: { beginAtZero: true } }
      }
    });
  }

  // Appointment Status Chart
  const statusCtx = document.getElementById('appointmentStatusChart');
  if (statusCtx) {
    new Chart(statusCtx, {
      type: 'pie',
      data: {
        labels: ['Completed', 'Scheduled', 'Cancelled', 'Pending'],
        datasets: [{
          data: [45, 30, 10, 15],
          backgroundColor: ['#10b981', '#0ea5e9', '#ef4444', '#f59e0b']
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false
      }
    });
  }
}

function initAdminForms() {
  // Add Doctor Form
  const addDoctorForm = document.getElementById('addDoctorForm');
  if (addDoctorForm) {
    addDoctorForm.addEventListener('submit', (e) => {
      e.preventDefault();
      if (Validator.validateForm(addDoctorForm, {
        name: ['required'],
        email: ['required', 'email'],
        phone: ['required', 'phone'],
        specialty: ['required'],
        department: ['required']
      })) {
        showToast('Doctor added successfully!', 'success');
        addDoctorForm.reset();
        document.getElementById('addDoctorModal')?.classList.remove('active');
      }
    });
  }

  // Add Patient Form
  const addPatientForm = document.getElementById('addPatientForm');
  if (addPatientForm) {
    addPatientForm.addEventListener('submit', (e) => {
      e.preventDefault();
      if (Validator.validateForm(addPatientForm, {
        name: ['required'],
        email: ['required', 'email'],
        phone: ['required', 'phone'],
        age: ['required', 'positiveNumber'],
        gender: ['required']
      })) {
        showToast('Patient added successfully!', 'success');
        addPatientForm.reset();
        document.getElementById('addPatientModal')?.classList.remove('active');
      }
    });
  }

  // Add Department Form
  const addDeptForm = document.getElementById('addDepartmentForm');
  if (addDeptForm) {
    addDeptForm.addEventListener('submit', (e) => {
      e.preventDefault();
      if (Validator.validateForm(addDeptForm, {
        name: ['required'],
        head: ['required'],
        description: ['required']
      })) {
        showToast('Department added successfully!', 'success');
        addDeptForm.reset();
        document.getElementById('addDepartmentModal')?.classList.remove('active');
      }
    });
  }
}

function initReportGeneration() {
  document.querySelectorAll('.generate-report').forEach(btn => {
    btn.addEventListener('click', () => {
      const reportType = btn.dataset.report;
      showToast(`Generating ${reportType} report...`, 'success');
      setTimeout(() => {
        showToast(`${reportType} report downloaded successfully!`, 'success');
      }, 2000);
    });
  });
}
