/**
 * Patient Dashboard Functionality
 */

document.addEventListener('DOMContentLoaded', () => {
  initProfileForm();
  initAppointmentCancellation();
  loadPatientAppointments();
});

function initProfileForm() {
  const form = document.getElementById('profileForm');
  if (!form) return;

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    if (Validator.validateForm(form, {
      firstName: ['required'],
      lastName: ['required'],
      email: ['required', 'email'],
      phone: ['required', 'phone'],
      dateOfBirth: ['required', 'date'],
      address: ['required']
    })) {
      showToast('Profile updated successfully!', 'success');
    }
  });
}

function initAppointmentCancellation() {
  document.querySelectorAll('.cancel-my-appointment').forEach(btn => {
    btn.addEventListener('click', () => {
      const row = btn.closest('tr') || btn.closest('.appointment-card');
      confirmDelete('this appointment', () => {
        const badge = row?.querySelector('.status-badge');
        if (badge) {
          badge.className = 'status-badge cancelled';
          badge.textContent = 'Cancelled';
        }
        showToast('Appointment cancelled successfully', 'success');
      });
    });
  });
}

function loadPatientAppointments() {
  const container = document.getElementById('patientAppointments');
  if (!container) return;

  const stored = JSON.parse(localStorage.getItem('hms-appointments') || '[]');
  if (stored.length === 0) return;

  stored.forEach(apt => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td data-label="Doctor">${apt.doctor}</td>
      <td data-label="Department">${apt.department}</td>
      <td data-label="Date">${apt.date}</td>
      <td data-label="Time">${apt.time}</td>
      <td data-label="Status"><span class="status-badge scheduled">${apt.status}</span></td>
      <td data-label="Actions">
        <div class="table-action-btns">
          <button class="table-action-btn view" title="View"><i class="fas fa-eye"></i></button>
          <button class="table-action-btn delete cancel-my-appointment" title="Cancel"><i class="fas fa-times"></i></button>
        </div>
      </td>
    `;
    container.appendChild(row);
  });
}

function downloadPrescription(id) {
  showToast('Downloading prescription...', 'success');
  setTimeout(() => showToast('Prescription downloaded!', 'success'), 1500);
}
