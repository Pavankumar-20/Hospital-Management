/**
 * Doctor Dashboard Functionality
 */

document.addEventListener('DOMContentLoaded', () => {
  initPrescriptionForm();
  initAppointmentActions();
  initScheduleManagement();
});

function initPrescriptionForm() {
  const form = document.getElementById('prescriptionForm');
  if (!form) return;

  let medicineCount = 1;

  document.getElementById('addMedicine')?.addEventListener('click', () => {
    medicineCount++;
    const container = document.getElementById('medicinesContainer');
    const row = document.createElement('div');
    row.className = 'form-row medicine-row';
    row.innerHTML = `
      <div class="form-group">
        <label class="form-label">Medicine Name</label>
        <input type="text" class="form-control" name="medicine${medicineCount}" required>
      </div>
      <div class="form-group">
        <label class="form-label">Dosage</label>
        <input type="text" class="form-control" name="dosage${medicineCount}" placeholder="e.g., 1 tablet twice daily" required>
      </div>
      <div class="form-group">
        <label class="form-label">Duration</label>
        <input type="text" class="form-control" name="duration${medicineCount}" placeholder="e.g., 7 days" required>
      </div>
    `;
    container.appendChild(row);
  });

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    showToast('Prescription saved successfully!', 'success');
    form.reset();
    document.getElementById('prescriptionModal')?.classList.remove('active');
  });
}

function initAppointmentActions() {
  document.querySelectorAll('.complete-appointment').forEach(btn => {
    btn.addEventListener('click', () => {
      const row = btn.closest('tr');
      const badge = row?.querySelector('.status-badge');
      if (badge) {
        badge.className = 'status-badge completed';
        badge.textContent = 'Completed';
      }
      showToast('Appointment marked as completed', 'success');
    });
  });

  document.querySelectorAll('.cancel-appointment').forEach(btn => {
    btn.addEventListener('click', () => {
      const row = btn.closest('tr');
      const badge = row?.querySelector('.status-badge');
      if (badge) {
        badge.className = 'status-badge cancelled';
        badge.textContent = 'Cancelled';
      }
      showToast('Appointment cancelled', 'warning');
    });
  });
}

function initScheduleManagement() {
  document.querySelectorAll('.schedule-slot').forEach(slot => {
    slot.addEventListener('click', () => {
      slot.classList.toggle('selected');
    });
  });

  const saveScheduleBtn = document.getElementById('saveSchedule');
  saveScheduleBtn?.addEventListener('click', () => {
    showToast('Schedule updated successfully!', 'success');
  });
}

function viewPatientHistory(patientId) {
  showToast(`Loading medical history for patient #${patientId}...`, 'success');
}
