/**
 * Appointment Booking Functionality
 */

const AppointmentManager = {
  doctors: {
    cardiology: [
      { id: 1, name: 'Dr. Sarah Wilson', specialty: 'Cardiologist' },
      { id: 2, name: 'Dr. Michael Chen', specialty: 'Cardiac Surgeon' }
    ],
    neurology: [
      { id: 3, name: 'Dr. Emily Parker', specialty: 'Neurologist' },
      { id: 4, name: 'Dr. James Rodriguez', specialty: 'Neurosurgeon' }
    ],
    orthopedics: [
      { id: 5, name: 'Dr. David Kumar', specialty: 'Orthopedic Surgeon' },
      { id: 6, name: 'Dr. Lisa Thompson', specialty: 'Sports Medicine' }
    ],
    pediatrics: [
      { id: 7, name: 'Dr. Anna Martinez', specialty: 'Pediatrician' },
      { id: 8, name: 'Dr. Robert Lee', specialty: 'Child Specialist' }
    ],
    dermatology: [
      { id: 9, name: 'Dr. Jennifer White', specialty: 'Dermatologist' }
    ],
    general: [
      { id: 10, name: 'Dr. Thomas Brown', specialty: 'General Physician' }
    ]
  },

  timeSlots: [
    '09:00 AM', '09:30 AM', '10:00 AM', '10:30 AM',
    '11:00 AM', '11:30 AM', '02:00 PM', '02:30 PM',
    '03:00 PM', '03:30 PM', '04:00 PM', '04:30 PM'
  ],

  init() {
    this.initDepartmentChange();
    this.initDatePicker();
    this.initTimeSlots();
    this.initBookingForm();
  },

  initDepartmentChange() {
    const deptSelect = document.getElementById('department');
    const doctorSelect = document.getElementById('doctor');
    if (!deptSelect || !doctorSelect) return;

    deptSelect.addEventListener('change', () => {
      const dept = deptSelect.value;
      doctorSelect.innerHTML = '<option value="">Select Doctor</option>';

      if (dept && this.doctors[dept]) {
        doctorSelect.disabled = false;
        this.doctors[dept].forEach(doc => {
          doctorSelect.innerHTML += `<option value="${doc.id}">${doc.name} - ${doc.specialty}</option>`;
        });
      } else {
        doctorSelect.disabled = true;
      }
    });
  },

  initDatePicker() {
    const dateInput = document.getElementById('appointmentDate');
    if (!dateInput) return;

    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    dateInput.min = tomorrow.toISOString().split('T')[0];

    const maxDate = new Date();
    maxDate.setMonth(maxDate.getMonth() + 3);
    dateInput.max = maxDate.toISOString().split('T')[0];

    dateInput.addEventListener('change', () => this.renderTimeSlots());
  },

  initTimeSlots() {
    this.renderTimeSlots();
  },

  renderTimeSlots() {
    const container = document.getElementById('timeSlots');
    if (!container) return;

    const dateInput = document.getElementById('appointmentDate');
    const selectedDate = dateInput?.value;

    container.innerHTML = '';

    if (!selectedDate) {
      container.innerHTML = '<p class="text-muted">Please select a date first</p>';
      return;
    }

    const dayOfWeek = new Date(selectedDate).getDay();
    if (dayOfWeek === 0) {
      container.innerHTML = '<p class="text-muted">No appointments available on Sundays</p>';
      return;
    }

    const bookedSlots = this.getBookedSlots(selectedDate);

    this.timeSlots.forEach(slot => {
      const isBooked = bookedSlots.includes(slot);
      const slotEl = document.createElement('div');
      slotEl.className = `time-slot ${isBooked ? 'disabled' : ''}`;
      slotEl.textContent = slot;

      if (!isBooked) {
        slotEl.addEventListener('click', () => {
          container.querySelectorAll('.time-slot').forEach(s => s.classList.remove('selected'));
          slotEl.classList.add('selected');
          document.getElementById('selectedTime').value = slot;
        });
      }

      container.appendChild(slotEl);
    });
  },

  getBookedSlots(date) {
    const appointments = JSON.parse(localStorage.getItem('hms-appointments') || '[]');
    return appointments
      .filter(a => a.date === date)
      .map(a => a.time);
  },

  initBookingForm() {
    const form = document.getElementById('bookingForm');
    if (!form) return;

    form.addEventListener('submit', (e) => {
      e.preventDefault();

      const isValid = Validator.validateForm(form, {
        department: ['required'],
        doctor: ['required'],
        appointmentDate: ['required', 'date', 'futureDate'],
        symptoms: ['required', { name: 'minLength', param: 10 }]
      });

      const selectedTime = document.getElementById('selectedTime')?.value;
      if (!selectedTime) {
        showToast('Please select a time slot', 'error');
        return;
      }

      if (!isValid) return;

      const appointment = {
        id: Date.now(),
        department: form.department.value,
        doctor: form.doctor.options[form.doctor.selectedIndex].text,
        date: form.appointmentDate.value,
        time: selectedTime,
        symptoms: form.symptoms.value,
        status: 'scheduled',
        createdAt: new Date().toISOString()
      };

      const appointments = JSON.parse(localStorage.getItem('hms-appointments') || '[]');
      appointments.push(appointment);
      localStorage.setItem('hms-appointments', JSON.stringify(appointments));

      this.showSuccessModal(appointment);
      form.reset();
      document.getElementById('selectedTime').value = '';
      this.renderTimeSlots();
    });
  },

  showSuccessModal(appointment) {
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay active';
    overlay.innerHTML = `
      <div class="modal">
        <div class="modal-body auth-success">
          <div class="auth-success-icon"><i class="fas fa-check"></i></div>
          <h3>Appointment Booked!</h3>
          <p>Your appointment with <strong>${appointment.doctor}</strong> has been scheduled for <strong>${appointment.date}</strong> at <strong>${appointment.time}</strong>.</p>
          <button class="btn btn-primary" onclick="this.closest('.modal-overlay').remove()">Done</button>
        </div>
      </div>
    `;
    document.body.appendChild(overlay);
    showToast('Appointment booked successfully!', 'success');
  }
};

document.addEventListener('DOMContentLoaded', () => AppointmentManager.init());
